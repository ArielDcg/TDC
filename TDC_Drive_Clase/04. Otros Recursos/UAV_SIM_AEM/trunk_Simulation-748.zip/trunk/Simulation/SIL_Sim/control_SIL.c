/******************************************************************************
 * FILE: control_manager_SIL.c
 * DESCRIPTION:
 * Software in the loop simulation (SILS) environment for V&V of onboard flight program (OFP).
 *
 *
 * University of Minnesota 
 * Aerospace Engineering and Mechanics 
 * Copyright 2011 Regents of the University of Minnesota. All rights reserved.
 *
 * $Id$
 ******************************************************************************/

#define S_FUNCTION_NAME control_SIL
#define S_FUNCTION_LEVEL 2

#include "simstruc.h"
#include "mex.h"
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <stddef.h>
#include <time.h>

// Include flightcode interfaces
#include "globaldefs.h"
#include "guidance/guidance_interface.h"
#include "control/control_interface.h"
#include "system_id/systemid_interface.h"
#include "faults/fault_interface.h"

#define NIN  2				/* number of input ports */
#define IP0_SIZE  19		/* size of input port 0*/
#define IP1_SIZE  2			/* size of input port 1*/
#define NOUT 2				/* number of output ports */
#define OP0_SIZE  7		    /* size of output port 0*/
#define OP1_SIZE  2		    /* size of output port 1*/
#define NPAR 1				/* number of S-function parameters */

#define dt        		*mxGetPr(ssGetSFcnParam(S,0))		// Software sample time, as an input parameter
#define time			ssGetT(S)							// Current simulation time		

// Data Structures 
struct  imu   imuData;
struct  gps   gpsData;
struct  nav   navData;
struct  control controlData;
struct  airdata adData;
// sensor data 
static struct sensordata sensorData;

/*========================================================================*
 *                          Initialization                                *
 *========================================================================*/

static void mdlInitializeSizes(SimStruct *S) {
    ssSetNumSFcnParams(S, NPAR);
    if(ssGetNumSFcnParams(S) != ssGetSFcnParamsCount(S))   return;
    
    if(!ssSetNumInputPorts(S, NIN)) return;
    
    {
        int_T   i;
        for(i = 0; i < NIN; i++){
            ssSetInputPortDirectFeedThrough(S, i, 1);
            ssSetInputPortDataType(S, i, DYNAMICALLY_TYPED);
        }
        
        ssSetInputPortWidth(S, 0, IP0_SIZE);
        ssSetInputPortWidth(S, 1, IP1_SIZE);
    }
    
    if(!ssSetNumOutputPorts(S, NOUT))    return;
    {
            ssSetOutputPortWidth(S, 0, OP0_SIZE);
			ssSetOutputPortWidth(S, 1, OP1_SIZE);
    }
    
    ssSetNumSampleTimes(S, 1);   
    
    sensorData.imuData_ptr = &imuData;
	sensorData.gpsData_ptr = &gpsData;
	sensorData.adData_ptr = &adData;
}

static void mdlInitializeSampleTimes(SimStruct *S) {
    ssSetSampleTime(S, 0, dt);
    ssSetOffsetTime(S, 0, 0.0);
}

static void mdlStart(SimStruct *S) {
    reset_control(&controlData); // reset any internal states in the controller
}

/*========================================================================*
 *                              Output                                    *
 *========================================================================*/
static void mdlOutputs(SimStruct *S, int_T tid) {
    // local variables
    real_T  *y0, *y1;
       
    // outputs
    y0 =  ssGetOutputPortRealSignal(S, 0);

    // outputs
    y1 =  ssGetOutputPortRealSignal(S, 1);	
       
    // Assign sensor data to feedback vector. 
    sensorData.imuData_ptr->phi = *ssGetInputPortRealSignalPtrs(S, 0)[0]; // phi
    sensorData.imuData_ptr->the = *ssGetInputPortRealSignalPtrs(S, 0)[1]; // theta
    sensorData.imuData_ptr->psi = *ssGetInputPortRealSignalPtrs(S, 0)[2]; // psi
    sensorData.imuData_ptr->p = *ssGetInputPortRealSignalPtrs(S, 0)[3]; // p
    sensorData.imuData_ptr->q = *ssGetInputPortRealSignalPtrs(S, 0)[4]; // q
    sensorData.imuData_ptr->r = *ssGetInputPortRealSignalPtrs(S, 0)[5]; // r
    sensorData.imuData_ptr->ax = *ssGetInputPortRealSignalPtrs(S, 0)[6]; // ax
    sensorData.imuData_ptr->ay = *ssGetInputPortRealSignalPtrs(S, 0)[7]; // ay
    sensorData.imuData_ptr->az = *ssGetInputPortRealSignalPtrs(S, 0)[8]; // az
	sensorData.adData_ptr->h = *ssGetInputPortRealSignalPtrs(S, 0)[9]; // h
	sensorData.adData_ptr->ias = *ssGetInputPortRealSignalPtrs(S, 0)[10]; // ias
    sensorData.adData_ptr->aoa = *ssGetInputPortRealSignalPtrs(S, 0)[11]; // alpha
    sensorData.adData_ptr->aos = *ssGetInputPortRealSignalPtrs(S, 0)[12]; // beta     
	navData.lat = *ssGetInputPortRealSignalPtrs(S, 0)[13]; // lat
    navData.lon = *ssGetInputPortRealSignalPtrs(S, 0)[14]; // lon
    navData.alt = *ssGetInputPortRealSignalPtrs(S, 0)[15]; // alt
    navData.vn = *ssGetInputPortRealSignalPtrs(S, 0)[16]; // vn
    navData.ve = *ssGetInputPortRealSignalPtrs(S, 0)[17]; // ve
    navData.vd = *ssGetInputPortRealSignalPtrs(S, 0)[18]; // vd

    
    //**** GUIDANCE **********************************************************
    #ifdef SIMULINK_GUIDANCE
        // Assign doublet sequences to references vector from Simulink
        controlData.phi_cmd = *ssGetInputPortRealSignalPtrs(S, 1)[0]; // roll command
        controlData.theta_cmd = *ssGetInputPortRealSignalPtrs(S, 1)[1]; // pitch command
    #else
        // Compute guidance (reference) commands for the control law
         guidance(time, &sensorData, &navData, &controlData);   
    #endif  
    //************************************************************************		

    //**** SENSOR FAULT ******************************************************
     sensor_fault(time, &sensorData, &navData, &controlData);
    //************************************************************************

    //**** CONTROL ***********************************************************
    control(time, &sensorData, &navData, &controlData);
    //************************************************************************

    //**** SYSTEM ID *********************************************************
    system_id(time, &sensorData, &navData, &controlData);
    //************************************************************************

    //**** SURACE FAULT ******************************************************
    surface_fault(time, &sensorData, &navData, &controlData);
    //************************************************************************

			
    // Assign to block outputs
    y0[0] = controlData.dthr; // Throttle deflection	
    y0[1] = controlData.de; // Elevator deflection
    y0[2] = controlData.dr; // Rudder deflection
	y0[3] = controlData.da_l; // Left Aileron deflection
    y0[4] = controlData.da_r; // Right Aileron deflection
	y0[5] = controlData.df_l; // Left flap deflection
    y0[6] = controlData.df_r; // Right flap deflection
	
	y1[0] = controlData.phi_cmd; // Roll angle command
	y1[1] = controlData.theta_cmd; // Pitch angle command
}


/*========================================================================*
 *                              Termination                               *
 *========================================================================*/

static void mdlTerminate(SimStruct *S) {
    reset_control(&controlData);
}

#ifdef  MATLAB_MEX_FILE    /* Is this file being compiled as a MEX-file? */
#include "simulink.c"      /* MEX-file interface mechanism */
#else
#include "cg_sfun.h"       /* Code generation registration function */
#endif
// ========================================================================================================

